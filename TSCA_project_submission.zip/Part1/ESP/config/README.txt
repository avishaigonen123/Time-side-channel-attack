גונן קח תקובץ ותכניס לתוך 
.pio\libdeps\esp32doit-devkit-v1\TFT_eSPI\User_Setup.h
